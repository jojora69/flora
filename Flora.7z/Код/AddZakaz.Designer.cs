﻿
namespace _1
{
    partial class AddZakaz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.name_zak = new System.Windows.Forms.ComboBox();
            this.flowersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.student_floraDataSet = new _1.student_floraDataSet();
            this.adresMag_zak = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.backmain = new System.Windows.Forms.Button();
            this.kol_vo_zak = new System.Windows.Forms.TextBox();
            this.buttonaddzak = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.closebutton = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.flowersTableAdapter = new _1.student_floraDataSetTableAdapters.flowersTableAdapter();
            this.label5 = new System.Windows.Forms.Label();
            this.tel_zak = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.flowersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_floraDataSet)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FloralWhite;
            this.panel1.Controls.Add(this.tel_zak);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.name_zak);
            this.panel1.Controls.Add(this.adresMag_zak);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label_name);
            this.panel1.Controls.Add(this.backmain);
            this.panel1.Controls.Add(this.kol_vo_zak);
            this.panel1.Controls.Add(this.buttonaddzak);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(476, 464);
            this.panel1.TabIndex = 2;
            // 
            // name_zak
            // 
            this.name_zak.DataSource = this.flowersBindingSource;
            this.name_zak.DisplayMember = "name";
            this.name_zak.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.name_zak.FormattingEnabled = true;
            this.name_zak.Location = new System.Drawing.Point(105, 127);
            this.name_zak.Name = "name_zak";
            this.name_zak.Size = new System.Drawing.Size(188, 21);
            this.name_zak.TabIndex = 17;
            this.name_zak.ValueMember = "id";
            // 
            // flowersBindingSource
            // 
            this.flowersBindingSource.DataMember = "flowers";
            this.flowersBindingSource.DataSource = this.student_floraDataSet;
            // 
            // student_floraDataSet
            // 
            this.student_floraDataSet.DataSetName = "student_floraDataSet";
            this.student_floraDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // adresMag_zak
            // 
            this.adresMag_zak.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.adresMag_zak.FormattingEnabled = true;
            this.adresMag_zak.Items.AddRange(new object[] {
            "Карамзина, 16",
            "Мира, 12 ",
            "Ярыгинская набережная, 8"});
            this.adresMag_zak.Location = new System.Drawing.Point(162, 220);
            this.adresMag_zak.Name = "adresMag_zak";
            this.adresMag_zak.Size = new System.Drawing.Size(191, 21);
            this.adresMag_zak.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 220);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 21);
            this.label4.TabIndex = 15;
            this.label4.Text = "Адрес Магазина";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 21);
            this.label3.TabIndex = 13;
            this.label3.Text = "Количество";
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_name.Location = new System.Drawing.Point(13, 127);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(86, 21);
            this.label_name.TabIndex = 12;
            this.label_name.Text = "Название";
            // 
            // backmain
            // 
            this.backmain.BackColor = System.Drawing.Color.DarkOrchid;
            this.backmain.Cursor = System.Windows.Forms.Cursors.Hand;
            this.backmain.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.backmain.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkMagenta;
            this.backmain.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Violet;
            this.backmain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.backmain.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.backmain.ForeColor = System.Drawing.Color.FloralWhite;
            this.backmain.Location = new System.Drawing.Point(277, 370);
            this.backmain.Name = "backmain";
            this.backmain.Size = new System.Drawing.Size(159, 42);
            this.backmain.TabIndex = 11;
            this.backmain.Text = "Назад";
            this.backmain.UseVisualStyleBackColor = false;
            this.backmain.Click += new System.EventHandler(this.backmain_Click);
            // 
            // kol_vo_zak
            // 
            this.kol_vo_zak.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.kol_vo_zak.Location = new System.Drawing.Point(126, 172);
            this.kol_vo_zak.Multiline = true;
            this.kol_vo_zak.Name = "kol_vo_zak";
            this.kol_vo_zak.Size = new System.Drawing.Size(71, 23);
            this.kol_vo_zak.TabIndex = 8;
            // 
            // buttonaddzak
            // 
            this.buttonaddzak.BackColor = System.Drawing.Color.DarkOrchid;
            this.buttonaddzak.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonaddzak.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.buttonaddzak.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkMagenta;
            this.buttonaddzak.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Violet;
            this.buttonaddzak.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonaddzak.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonaddzak.ForeColor = System.Drawing.Color.FloralWhite;
            this.buttonaddzak.Location = new System.Drawing.Point(12, 370);
            this.buttonaddzak.Name = "buttonaddzak";
            this.buttonaddzak.Size = new System.Drawing.Size(159, 42);
            this.buttonaddzak.TabIndex = 5;
            this.buttonaddzak.Text = "Добавить";
            this.buttonaddzak.UseVisualStyleBackColor = false;
            this.buttonaddzak.Click += new System.EventHandler(this.buttonaddstat_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel2.Controls.Add(this.closebutton);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(476, 100);
            this.panel2.TabIndex = 0;
            // 
            // closebutton
            // 
            this.closebutton.AutoSize = true;
            this.closebutton.BackColor = System.Drawing.Color.Red;
            this.closebutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.closebutton.ForeColor = System.Drawing.Color.Gold;
            this.closebutton.Location = new System.Drawing.Point(428, 0);
            this.closebutton.Name = "closebutton";
            this.closebutton.Size = new System.Drawing.Size(27, 31);
            this.closebutton.TabIndex = 1;
            this.closebutton.Text = "x";
            this.closebutton.Click += new System.EventHandler(this.closebutton_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.DarkOrchid;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Unicode", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.FloralWhite;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(476, 100);
            this.label1.TabIndex = 0;
            this.label1.Text = "Добавить заказ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // flowersTableAdapter
            // 
            this.flowersTableAdapter.ClearBeforeFill = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 261);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 21);
            this.label5.TabIndex = 19;
            this.label5.Text = "Номер телефона";
            // 
            // tel_zak
            // 
            this.tel_zak.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tel_zak.Location = new System.Drawing.Point(167, 261);
            this.tel_zak.Multiline = true;
            this.tel_zak.Name = "tel_zak";
            this.tel_zak.Size = new System.Drawing.Size(191, 24);
            this.tel_zak.TabIndex = 20;
            // 
            // AddZakaz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(458, 438);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddZakaz";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddZakaz";
            this.Load += new System.EventHandler(this.AddZakaz_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.flowersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_floraDataSet)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox adresMag_zak;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Button backmain;
        private System.Windows.Forms.TextBox kol_vo_zak;
        private System.Windows.Forms.Button buttonaddzak;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label closebutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox name_zak;
        private student_floraDataSet student_floraDataSet;
        private System.Windows.Forms.BindingSource flowersBindingSource;
        private student_floraDataSetTableAdapters.flowersTableAdapter flowersTableAdapter;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tel_zak;
    }
}