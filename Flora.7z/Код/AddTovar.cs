﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1
{
    public partial class AddTovar : Form
    {
        public string modeS = "";
        int item;
        void setMode(string mode)
        {
            if (mode == "add")
            {
                buttonaddstat.Text = "Добавить";
            }
            else if (mode == "change")
            {
                label1.Text = "Редактировать товар";
                buttonaddstat.Text = "Изменить";
                string Info = "select name, kol_vo, price, adres_mag from flowers where id =" + item.ToString() + ";";
                MySqlConnection conn = DB.GetDBConnection();
                MySqlCommand cmInfo = new MySqlCommand(Info, conn);
                MySqlDataReader inRead;
                cmInfo.CommandTimeout = 60;
                try
                {
                    conn.Open();
                    inRead = cmInfo.ExecuteReader();
                    if (inRead.HasRows)
                    {
                        while (inRead.Read())
                        {
                            name_flow.Text = inRead.GetString(0);
                            kol_vo.Text = inRead.GetString(1);
                            price_flow.Text = inRead.GetString(2);
                            

                        }
                    }
                    conn.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        void getNames(ComboBox Box)
        {
            string query = "select name from flowers;";
            MySqlConnection conn = DB.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            MySqlDataReader rd;
            cmDB.CommandTimeout = 60;
            try
            {
                conn.Open();
                rd = cmDB.ExecuteReader();
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                        string row = rd.GetString(0);
                        Box.Items.Add(row);
                    }
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        public AddTovar(string mode, int id)
        {
            InitializeComponent();
            

            modeS = mode;
            item = id;
            setMode(mode);
            
        }


        private void closebutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void closebutton_MouseEnter(object sender, EventArgs e)
        {
            closebutton.ForeColor = Color.White;
        }

        private void closebutton_MouseLeave(object sender, EventArgs e)
        {
            closebutton.ForeColor = Color.Gold;
        }

        private void backmain_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm1 mainForm1 = new MainForm1();
            mainForm1.Show();
        }

        private void buttonaddstat_Click(object sender, EventArgs e)
        {
            if (name_flow.Text == "")
            {
                MessageBox.Show("Введите название");
                return;
            }

            if (kol_vo.Text == "")
            {
                MessageBox.Show("Введите количество");
                return;
            }

            if (price_flow.Text == "")
            {
                MessageBox.Show("Введите цену");
                return;
            }

            if (modeS == "add")
            {
                string query = "insert into flowers(name, kol_vo, price, adres_mag) values('" + name_flow.Text + "', '" + kol_vo.Text + "', '" + price_flow.Text + "', '" + adresMag.Text + "');";
                MySqlConnection conn = DB.GetDBConnection();
                MySqlCommand cmDB = new MySqlCommand(query, conn);
                cmDB.CommandTimeout = 60;
                try
                {
                    conn.Open();
                    MySqlDataReader rd = cmDB.ExecuteReader();
                    conn.Close();
                    MessageBox.Show("Товар была добавлен.");
                    this.Hide();
                    MainForm1 mainForm1 = new MainForm1();
                    mainForm1.Show();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Товар не добавлен.");
                    MessageBox.Show(ex.Message);
                }
            }
            if (modeS == "change")
            {
                string content = name_flow.Text.ToString();
                string query = "update flowers set name ='" + name_flow.Text + "', kol_vo='" + kol_vo.Text + "', price='" + price_flow.Text + "', adres_mag='" + adresMag.Text + "' where id = " + item.ToString() + ";";
                MySqlConnection conn = DB.GetDBConnection();
                MySqlCommand cmDB = new MySqlCommand(query, conn);
                cmDB.CommandTimeout = 60;
                try
                {
                    conn.Open();
                    MySqlDataReader rd = cmDB.ExecuteReader();
                    conn.Close();
                    MessageBox.Show("Товар был изменен.");
                    this.Hide();
                    MainForm1 mainForm1 = new MainForm1();
                    mainForm1.Show();
                    

                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Товар не изменен.");
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void AddTovar_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "student_floraDataSet1.flowers". При необходимости она может быть перемещена или удалена.
            this.flowersTableAdapter.Fill(this.student_floraDataSet1.flowers);

        }
    }
}
