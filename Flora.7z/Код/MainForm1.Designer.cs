﻿
namespace _1
{
    partial class MainForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.redact_stat = new System.Windows.Forms.Button();
            this.addstat = new System.Windows.Forms.Button();
            this.delstat = new System.Windows.Forms.Button();
            this.list = new System.Windows.Forms.ListView();
            this.name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.kol_vo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.price = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.adres_mag = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel2 = new System.Windows.Forms.Panel();
            this.closebutton = new System.Windows.Forms.Label();
            this.add_zak = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FloralWhite;
            this.panel1.Controls.Add(this.add_zak);
            this.panel1.Controls.Add(this.redact_stat);
            this.panel1.Controls.Add(this.addstat);
            this.panel1.Controls.Add(this.delstat);
            this.panel1.Controls.Add(this.list);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(571, 566);
            this.panel1.TabIndex = 1;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            // 
            // redact_stat
            // 
            this.redact_stat.Location = new System.Drawing.Point(409, 447);
            this.redact_stat.Name = "redact_stat";
            this.redact_stat.Size = new System.Drawing.Size(142, 41);
            this.redact_stat.TabIndex = 4;
            this.redact_stat.Text = "Редактировать товар";
            this.redact_stat.UseVisualStyleBackColor = true;
            this.redact_stat.Click += new System.EventHandler(this.redact_stat_Click);
            // 
            // addstat
            // 
            this.addstat.Location = new System.Drawing.Point(409, 400);
            this.addstat.Name = "addstat";
            this.addstat.Size = new System.Drawing.Size(142, 41);
            this.addstat.TabIndex = 3;
            this.addstat.Text = "Добавить товар";
            this.addstat.UseVisualStyleBackColor = true;
            this.addstat.Click += new System.EventHandler(this.addstat_Click);
            // 
            // delstat
            // 
            this.delstat.Location = new System.Drawing.Point(19, 447);
            this.delstat.Name = "delstat";
            this.delstat.Size = new System.Drawing.Size(142, 41);
            this.delstat.TabIndex = 2;
            this.delstat.Text = "Удалить товар";
            this.delstat.UseVisualStyleBackColor = true;
            this.delstat.Click += new System.EventHandler(this.delstat_Click);
            // 
            // list
            // 
            this.list.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.id,
            this.name,
            this.kol_vo,
            this.price,
            this.adres_mag});
            this.list.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.list.HideSelection = false;
            this.list.Location = new System.Drawing.Point(19, 138);
            this.list.Margin = new System.Windows.Forms.Padding(0);
            this.list.Name = "list";
            this.list.Size = new System.Drawing.Size(532, 235);
            this.list.TabIndex = 1;
            this.list.UseCompatibleStateImageBehavior = false;
            this.list.View = System.Windows.Forms.View.Details;
            // 
            // name
            // 
            this.name.Text = "Название";
            this.name.Width = 140;
            // 
            // kol_vo
            // 
            this.kol_vo.Text = "Количество";
            this.kol_vo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.kol_vo.Width = 90;
            // 
            // price
            // 
            this.price.Text = "Цена";
            this.price.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // adres_mag
            // 
            this.adres_mag.Text = "Адрес магазина";
            this.adres_mag.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.adres_mag.Width = 210;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel2.Controls.Add(this.closebutton);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(571, 100);
            this.panel2.TabIndex = 0;
            // 
            // closebutton
            // 
            this.closebutton.AutoSize = true;
            this.closebutton.BackColor = System.Drawing.Color.Red;
            this.closebutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.closebutton.ForeColor = System.Drawing.Color.Gold;
            this.closebutton.Location = new System.Drawing.Point(541, 0);
            this.closebutton.Name = "closebutton";
            this.closebutton.Size = new System.Drawing.Size(27, 31);
            this.closebutton.TabIndex = 1;
            this.closebutton.Text = "x";
            this.closebutton.Click += new System.EventHandler(this.closebutton_Click);
            this.closebutton.MouseEnter += new System.EventHandler(this.closebutton_MouseEnter);
            this.closebutton.MouseLeave += new System.EventHandler(this.closebutton_MouseLeave);
            // 
            // add_zak
            // 
            this.add_zak.Location = new System.Drawing.Point(19, 400);
            this.add_zak.Name = "add_zak";
            this.add_zak.Size = new System.Drawing.Size(142, 41);
            this.add_zak.TabIndex = 5;
            this.add_zak.Text = "Добавить заказ";
            this.add_zak.UseVisualStyleBackColor = true;
            this.add_zak.Click += new System.EventHandler(this.add_zak_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.ForestGreen;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Unicode", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Image = global::_1.Properties.Resources.istockphoto_518856246_1024x1024;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(571, 100);
            this.label1.TabIndex = 0;
            this.label1.Text = "Флора";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label1_MouseDown);
            this.label1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label1_MouseMove);
            // 
            // id
            // 
            this.id.Text = "ID";
            this.id.Width = 25;
            // 
            // MainForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 557);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainForm1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm1";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label closebutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ColumnHeader kol_vo;
        private System.Windows.Forms.ColumnHeader price;
        private System.Windows.Forms.ColumnHeader adres_mag;
        private System.Windows.Forms.Button addstat;
        private System.Windows.Forms.Button delstat;
        public System.Windows.Forms.ListView list;
        private System.Windows.Forms.ColumnHeader name;
        private System.Windows.Forms.Button redact_stat;
        private System.Windows.Forms.Button add_zak;
        private System.Windows.Forms.ColumnHeader id;
    }
}