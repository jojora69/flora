﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    class DB
    {
        public static MySqlConnection GetDBConnection()
        {
            string host = "kkrit.site";
            int port = 3306;
            string database = "student_flora";
            string username = "student";
            string password = "student";

            return DBMySQLUtils.GetDBConnection(host, port, database, username, password);
        }

        MySqlConnection connection = new MySqlConnection("server=kkrit.site;port=3306;username=student;password=student;database=student_flora");

        public void openConnection()
        {
            if (connection.State == System.Data.ConnectionState.Closed)
                connection.Open();
        }

        public void closeConnection()
        {
            if (connection.State == System.Data.ConnectionState.Open)
                connection.Close();
        }

        public MySqlConnection getConnection()
        {
            return connection;
        }
    }
}
