﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1
{
    public partial class AddZakaz : Form
    {
        public AddZakaz()
        {
            InitializeComponent();
        }

        private void closebutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AddZakaz_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "student_floraDataSet.flowers". При необходимости она может быть перемещена или удалена.
            this.flowersTableAdapter.Fill(this.student_floraDataSet.flowers);

        }

        private void buttonaddstat_Click(object sender, EventArgs e)
        {
            string query = "insert into zakaz(name_zak, kol_vo_zak, adres_mag_zak, nomer_zak) values('" + name_zak.Text + "', '" + kol_vo_zak.Text + "', '" + adresMag_zak.Text + "', '" + tel_zak.Text + "');";
            MySqlConnection conn = DB.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            cmDB.CommandTimeout = 60;
            try
            {
                conn.Open();
                MySqlDataReader rd = cmDB.ExecuteReader();
                conn.Close();
                MessageBox.Show("Ваш заказ оформлен. В скором вам перезвонят.");
                this.Hide();
                MainForm1 mainForm1 = new MainForm1();
                mainForm1.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка попробуйте позже");
                MessageBox.Show(ex.Message);
            }
        }

        private void backmain_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm1 mainForm1 = new MainForm1();
            mainForm1.Show();
        }
    }
}
